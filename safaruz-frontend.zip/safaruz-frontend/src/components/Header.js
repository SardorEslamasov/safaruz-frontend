import React from "react";

const Header = () => {
  return <header><h2>SafarUz Header</h2></header>;
};

export default Header;
