import React from "react";

const Footer = () => {
  return <footer><p>SafarUz Footer</p></footer>;
};

export default Footer;
