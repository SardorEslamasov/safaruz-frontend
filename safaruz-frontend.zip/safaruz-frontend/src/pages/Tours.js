import React from "react";

const Tours = () => {
  return <h1>Tours Page</h1>;
};

export default Tours;
