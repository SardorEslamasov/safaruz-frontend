import React from "react";

const Booking = () => {
  return <div>Booking Page (Coming Soon)</div>;
};

export default Booking;
