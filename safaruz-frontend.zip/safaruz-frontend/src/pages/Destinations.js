import React from "react";

const Destinations = () => {
  return <h1>Destinations Page</h1>;
};

export default Destinations;
