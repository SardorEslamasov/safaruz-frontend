import React from "react";

const Hotels = () => {
  return <h1>Hotels Page</h1>;
};

export default Hotels;
