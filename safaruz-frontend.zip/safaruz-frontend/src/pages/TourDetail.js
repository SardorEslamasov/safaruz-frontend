import React from "react";

const TourDetail = () => {
  return <div>Tour Details (Coming Soon)</div>;
};

export default TourDetail;

