import React from "react";

const Restaurants = () => {
  return <h1>Restaurants Page</h1>;
};

export default Restaurants;
